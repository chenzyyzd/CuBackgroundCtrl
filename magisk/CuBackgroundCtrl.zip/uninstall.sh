#!/system/bin/sh
rm -rf /sdcard/Android/CuBackgroundCtrl
